//
//  ComKossoSwifti.h
//  SwifTi
//
//  Created by Kosso
//  Copyright (c) 2019 . All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for ComKossoSwifti.
FOUNDATION_EXPORT double ComKossoSwiftiVersionNumber;

//! Project version string for ComKossoSwifti.
FOUNDATION_EXPORT const unsigned char ComKossoSwiftiVersionString[];

#import "ComKossoSwiftiModuleAssets.h"
